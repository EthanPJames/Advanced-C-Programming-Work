#include <stdlib.h>
#include <stdio.h>

#include "answer07.h"

// macros used in Is_BMP_Header_Valid function

#define BMP_TYPE 0x4d42
#define BMP_HEADER_SIZE 54
#define DIB_HEADER_SIZE 40

BMP_image *read_BMP_image(char *filename)
{
  FILE *open = fopen(filename, "r"); // Is this the right data type???????????????
  if(open == NULL)
  {
    return(NULL);
  }
  BMP_image *my_image = malloc(sizeof(*my_image)); //?? Did I malloc this correctly? mall 
  
  if(my_image == NULL)
  {
    
    fclose(open);
    return(NULL);
  }
  //Is followng fread correct ???????????????????????????????????????? check sizeof
  fseek(open, 0l, SEEK_SET);
  if(fread(&(my_image->header), sizeof(my_image->header), 1 , open) != 1) //???? IS the one correct, Is this format correct???
  {
    fclose(open);
    free(my_image);
    return(NULL);
  }
   int valid_header = is_BMP_header_valid(&my_image->header, open); //???What do i put as parameters
  if(valid_header == 0)
  {
    fclose(open);
    free(my_image); 
    return(NULL);
    
  }
  fseek(open, 54l, SEEK_SET);
  my_image->data = calloc(my_image->header.imagesize, sizeof(*(my_image->data))); //Allocate space for image data???????????????????????
  if(my_image->data == NULL)
  {
    fclose(open);
    free(my_image);
    return(NULL);
  }
  //Is the following correct???????????????????????????????
  if(fread((my_image->data), sizeof(*(my_image->data)), my_image->header.imagesize, open) != my_image->header.imagesize)
  {
    fclose(open);
    free(my_image);
    free(my_image->data); 
    return(NULL);
    
  }
  //Sub function below called to check for valid header
 
  ///Would i free anything here????
  fclose(open); 
  return(my_image);


} 



/* check whether a header is valid
 * assume that header has been read from fptr
 * the position of the indicator of fptr is not certain
 * could be at the beginning of the file, end of the file or 
 * anywhere in the file
 * note that the check is only for this exercise/assignment
 * in general, the format is more complicated
 */

int is_BMP_header_valid(BMP_header* header, FILE *fptr) {
  // Make sure this is a BMP file
  if (header->type != BMP_TYPE) {
     return 0;
  }
  // skip the two unused reserved fields
  

  // check the offset from beginning of file to image data
  // essentially the size of the BMP header
  // BMP_HEADER_SIZE for this exercise/assignment
  if (header->offset != BMP_HEADER_SIZE) {
     return 0;
  }
      
  // check the DIB header size == DIB_HEADER_SIZE
  // For this exercise/assignment
  if (header->DIB_header_size != DIB_HEADER_SIZE) {
     return 0;
  }

  // Make sure there is only one image plane
  if (header->planes != 1) {
    return 0;
  }
  // Make sure there is no compression
  if (header->compression != 0) {
    return 0;
  }

  // skip the test for xresolution, yresolution

  // ncolours and importantcolours should be 0
  if (header->ncolours != 0) {
    return 0;
  }
  if (header->importantcolours != 0) {
    return 0;
  }
  
  // Make sure we are getting 24 bits per pixel
  // or 16 bits per pixel
  if (header->bits != 24 && header->bits != 16) {
    return 0;
  }

  // fill in code to check for file size, image size
  // based on bits, width, and height
  //What I have added(Ethan James)
  
  
  int math_16bit = 0;
  int byte_total;
  
  if(header->bits == 24)
  {
    int math_24bit = (((header->width * 3 * 8) + 31) / 32) * 4;
    byte_total = math_24bit * header->height;
    if(header->imagesize != byte_total)
    {
      return(0);
    }
  }
 
  
  if(header->bits == 16)
  {
    math_16bit = (((header->width * 2 * 8) + 31) / 32) * 4;
    byte_total = math_16bit * header->height;
    if(header->imagesize != byte_total)
    {
      return(0);
    }
  }
  fseek(fptr, 0l, SEEK_END);
  if(ftell(fptr) != header->size)
  {
    return(0);
  }
  
  return 1;
}

int write_BMP_image(char *filename, BMP_image *image)
{
  FILE *open = fopen(filename, "w"); //Open the output file to write to
  if (open == NULL)
  {
    
    return(0);
  }
  
  //Check this fwrite, what is the parameters for the fwrite here
  fseek(open, 0l, SEEK_SET);
  if(fwrite(&(image->header), sizeof(image->header), 1 , open) != 1)
  {
    fclose(open);
    return(0);
  }
  if(fwrite(image->data, sizeof(*(image->data)) , image->header.imagesize, open) != image->header.imagesize) //??What goes in this fwrite statement???????????????????????????????????????????
  {
    fclose(open);
    return(0);

  }
  fclose(open);
  return(1);
}

//????Is this following function correct?????????
void free_BMP_image(BMP_image *image)
{
  free(image->data);
  free(image);
}



BMP_image *convert_24_to_16_BMP_image(BMP_image *image)
{
  BMP_image *new =  malloc(sizeof(*new));
  if(new == NULL)
  {
    return(NULL);
  }
  new->header = image->header;
 

  new->header.width = image->header.width; //Does not change
  new->header.height = image->header.height; //Does not change
  new->header.bits = 16;

  int math_24bit = 0;
  math_24bit = ((((new->header.width * 2 * 8) + 31) / 32) * 4);
  new->header.imagesize = math_24bit * new->header.height;
  new->header.size = new->header.imagesize + sizeof(new->header); //New header conversion

  new->data = calloc(new->header.imagesize, sizeof(*(new->data)));
  if(new == NULL)
  {
    free(new);
    return(NULL);
  }

  //Or bit-wise operator shift
  int red;
  int blue;
  int green; 
  int ccount = 1;
  int ncount = 0;
  int shift;
  int control = 0;
  int modulus = 0;

  int pad = 0;
  if((image->header.width * 3) % 4 == 1)
  {
    pad = pad + 1;
  }
   if((image->header.width * 3) % 4 == 2);
  {
    pad = pad + 2;
  }
   if((image->header.width * 3) % 4 == 3);
  {
    pad = pad + 3;
  }



  while(control < image->header.imagesize) //??? Should this be 99, also what should I change??
  {
    if(ccount == 3) //Should this be equal to 3
    {
      red = image->data[control] >> 3;
      red = red << 10;
    }
    else if(ccount == 2)
    {
      green = image->data[control] >>3;
      green = green << 5;
    }
    else if(ccount == 1)
    {
      blue = image->data[control] >> 3;
      blue = blue;
    }
    ccount = ccount + 1;

    if(ccount == 4)
    {
      shift = red | green | blue;
      shift = shift << 8;
      new->data[ncount] = shift >> 8;
      ncount = ncount + 1;
      shift = red | green | blue;
      new->data[ncount] = shift >> 8;
      ncount = ncount + 1;
      ccount = 1;
      
    }
    modulus = control % (((((image->header.width * 3 * 8) + 31) / 32) * 4));
    if(modulus == 0 && control != 0)
    {
      control = control + pad; //Accont for padding
    }
    control = control + 1;
  }

return(new);
}

BMP_image *convert_16_to_24_BMP_image(BMP_image *image)
{
  BMP_image *new =  malloc(sizeof(*image));
  if(new == NULL)
  {
    return(NULL);
  }
   new->header = image->header;
 

  new->header.width = image->header.width; //Does not change
  new->header.height = image->header.height; //Does not change
  new->header.bits = 24;

  int math_24bit = 0;
  math_24bit = ((((new->header.width * 3 * 8) + 31) / 32) * 4);
  new->header.imagesize = math_24bit * new->header.height;
  new->header.size = new->header.imagesize + sizeof(new->header); //New header conversion

  new->data = calloc(new->header.imagesize, sizeof(*(new->data)));
  if(new == NULL)
  {
    free(new);
    return(NULL);
  }
  

  return(new);

}